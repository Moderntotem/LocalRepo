# part-time-functions

### To get started, clone this repo inside whatever folder you store your projects inside using the command:
`git clone https://github.com/johnazre/part-time-functions.git`

#### After doing that, open `index.html`. Then, open the folder and open `src/main.js`. Complete the exercises within that folder, refreshing `index.html` inside the browser after making changes.
